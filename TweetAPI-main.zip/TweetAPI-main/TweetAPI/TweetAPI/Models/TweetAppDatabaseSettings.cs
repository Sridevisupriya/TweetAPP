﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TweetAPI.Models
{
    public class TweetAppDatabaseSettings
    {
        public string ConnectionString { get; set; }

        public string DatabaseName { get; set; } 

        public string UserCollectionName { get; set; } 
    }
}
