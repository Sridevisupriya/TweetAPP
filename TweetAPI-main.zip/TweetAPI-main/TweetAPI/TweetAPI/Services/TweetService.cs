﻿using Microsoft.Extensions.Configuration;
using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAPI.Models;
using TweetAPI.Repository;

namespace TweetAPI.Services
{
    public class TweetService : ITweetService
    {
        private readonly ITweetRepository _tweetRepo;
        private IConfiguration _config;
        private static readonly log4net.ILog _log4net = log4net.LogManager.GetLogger(typeof(TweetService));
        public TweetService(ITweetRepository tweetRepo, IConfiguration configuration)
        {
            _tweetRepo = tweetRepo;
            _config = configuration;
        }

        public Tweet CreateTweet(Tweet tweet)
        {
            var result = _tweetRepo.CreateTweet(tweet);
            _log4net.Info("Tweet Created Successfully");
            return result;
        }

        public bool Delete(int id)
        {
           var res = _tweetRepo.Delete(id);
            if(res)
            {
                _log4net.Info("Tweet Deleted Successfully");
                return true;
            }
            else
            {
                _log4net.Error("Tweet Deletionis UnSuccessfull");
                return false;
            }            
        }

        public IEnumerable<Tweet> GetAllTweets()
        {
            var result = _tweetRepo.GetAllTweets();
            if (result != null)
            {
                _log4net.Info("Retriveing all tweets Successfully");
                return result;
            }
            else
            {
                _log4net.Info("No Records to retrieve");
                return null;
            }
        }

        public IEnumerable<Tweet> GetAllTweetsOfUser(string userName)
        {
            var result = _tweetRepo.GetAllTweetsOfUser(userName);
            if (result != null)
            {
                _log4net.Info("Retrived all tweets by userName");
                return result;
            }
            else
            {
                _log4net.Info("User doesn't exists");
                return null;
            }
        }

        public void LikeIncrement(int id)
        {
            _log4net.Info("Liked the tweet");
            _tweetRepo.LikeIncrement(id);
        }

        public Tweet UpdateTweet(int id, Tweet tweet)
        {
            var result = _tweetRepo.UpdateTweet(id, tweet);
            if (result != null)
            {
                _log4net.Info("Updated the tweet");
                return result;
            }
            else
            {
                _log4net.Info("Tweet doesn't exists");
                return null;
            }
        }
    }
}
