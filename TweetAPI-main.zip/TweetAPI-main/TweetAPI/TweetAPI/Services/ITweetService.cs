﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAPI.Models;

namespace TweetAPI.Services
{
    public interface ITweetService
    {
        public IEnumerable<Tweet> GetAllTweets();
        public IEnumerable<Tweet> GetAllTweetsOfUser(string userName);
        public Tweet UpdateTweet(int id, Tweet tweet);
        public bool Delete(int id);
        public void LikeIncrement(int id);
        public Tweet CreateTweet(Tweet tweet);
    }
}
