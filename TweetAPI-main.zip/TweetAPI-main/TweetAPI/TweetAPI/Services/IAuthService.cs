﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAPI.Dto;
using TweetAPI.Models;
namespace TweetAPI.Services
{
    public interface IAuthService
    {
        public UserDto CreateUser(RegisterUser newUser);
        public string GetUser(LoginUser userDetails);
        public UserDto ForgetPassword(ForgetPasswordUser fpUser);
        public List<UserDto> GetAllUsers();
        public UserDto GetByUserName(string loginId);
    }
}
