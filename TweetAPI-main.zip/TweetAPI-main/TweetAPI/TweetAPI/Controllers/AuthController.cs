﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAPI.Models;
using TweetAPI.Services;
using TweetAPI.Dto;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using Microsoft.AspNetCore.Authorization;

namespace TweetAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private static readonly log4net.ILog _log4net = log4net.LogManager.GetLogger(typeof(AuthController));
        private readonly IAuthService _authService;
        public AuthController(IAuthService authService) => _authService = authService;

        [AllowAnonymous]
        [HttpPost("register")]
        public IActionResult Register([FromBody] RegisterUser newUser)
        {
            try
            {
                var resUser = _authService.CreateUser(newUser);
                if (resUser != null)
                {
                    _log4net.Info("User registered successfully");
                    return Ok();
                }
                    
                else
                {
                    _log4net.Info("Error Processing the request of Register User");
                    return BadRequest();
                }
                    
            }
            catch (Exception e)
            {
                _log4net.Error("Unexpected error occured during registeration of user" + e.Message);
                return StatusCode(500);
            }
        }

        [HttpPost("loginId/forgetPassword")]
        public IActionResult ForgetPassword([FromBody] ForgetPasswordUser fpUser)
        {
            try
            {
                var userDetails = _authService.ForgetPassword(fpUser);
                if (userDetails != null)
                {
                    _log4net.Info("User successfully changed password");
                    return Ok();
                }
                else
                {
                    _log4net.Info("Error Processing the request of ForgetPassword");
                    return NotFound();
                }
            }
            catch (Exception e)
            {
                _log4net.Error("Unexpected error occured during the process of request" + e.Message);
                return BadRequest();
            }
        }
        [HttpGet("users/all")]
        public IActionResult Get()
        {
            try
            {
               var userList = _authService.GetAllUsers();
                if(userList.Count > 0)
                {
                    _log4net.Info("Retriving All Users Successful");
                    return Ok(userList);
                }
                else
                {
                    _log4net.Info("Error Processing the request of get all users");
                    return NotFound();
                }
                
            }
            catch(Exception e)
            {
                _log4net.Error("Unexpected error occured during the process of request" + e.Message);
                return BadRequest();
            }
        }
        [AllowAnonymous]
        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginUser user)
        {
            if (!ModelState.IsValid)
            {
                return StatusCode(400, "Invalid data given as credentials");
            }
            _log4net.Info("Login Initiated for user " + user.LoginID);
            try
            {
                string token = _authService.GetUser(user);
                if (token == null)
                {
                    _log4net.Info("User does not exist");
                    return StatusCode(404, "User does not exist");
                }
                else
                {

                    _log4net.Info("Successfully logged In and token returned for user " + user.LoginID);
                    return Ok(new { token = token });
                }
            }
            catch (Exception e)
            {
                _log4net.Error("Unexpected error occured during login of user " + user.LoginID + " with message" + e.Message);
                return StatusCode(500, "Unexpected error occured during login");
            }

        }
        [HttpGet("users/search/username")]
        public IActionResult GetByUserName(string loginId)
        {
            try
            {
                var userDetails = _authService.GetByUserName(loginId);
                if (userDetails != null)
                {
                    _log4net.Info("User Retrieved Successful");
                    return Ok(userDetails);
                }
                else
                {
                    _log4net.Info("Error Processing the request of get by user name");
                    return NotFound();
                }

            }
            catch (Exception e)
            {
                _log4net.Error("Unexpected error occured during the process of request" + e.Message);
                return BadRequest();
            }
        }

    }
}
